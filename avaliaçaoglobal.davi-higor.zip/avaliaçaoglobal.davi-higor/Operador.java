public class Operador extends Funcionario {
    private int horasExtras;

    public double Operador(String nome, int id , int horasExtras) {
        super(nome, id);
        this.horasExtras = horasExtras;{
        }

        double calcularHorasExtras;{
            return horasExtras * 1.5;
        }
    }

    @Override
    public String toString() {
        return super.toString() + "Operador{" + "horasExtras=" + horasExtras + '}';
    }
}
