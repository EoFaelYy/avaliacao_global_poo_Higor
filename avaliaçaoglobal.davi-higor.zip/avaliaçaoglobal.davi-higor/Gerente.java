public class Gerente extends Funcionario{

    private double bonus;
    private double salario;

    public Gerente(String nome, String funcao, double salario, double bonus) {
        super(nome, funcao, salario);
        this.bonus = bonus;
    }

    @Override
    public void aplicarAumento(int percentual) {
        super.aplicarAumento(percentual*2);
    }

    public void calcularSalario(int percentual){
        this.salario += this.bonus;
    }
}